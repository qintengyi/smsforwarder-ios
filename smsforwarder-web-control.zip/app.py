from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from config import Config
from utils import sms_forwarder_api
import time
import re

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = Config.SECRET_KEY

# 注册模板过滤器
@app.template_filter('timestamp_to_datetime')
def timestamp_to_datetime(timestamp):
    if not timestamp:
        return ''
    try:
        timestamp = int(timestamp)
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp / 1000))
    except (ValueError, TypeError):
        return str(timestamp)

def is_valid_mac(mac):
    """验证MAC地址格式"""
    mac_pattern = r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$'
    return re.match(mac_pattern, mac) is not None

# 首页 - 仪表盘
@app.route('/')
def dashboard():
    # 获取配置信息
    config_response = sms_forwarder_api.query_config()
    
    # 获取电量信息
    battery_response = sms_forwarder_api.query_battery()
    
    # 获取定位信息
    location_response = sms_forwarder_api.query_location()
    
    return render_template('dashboard.html', 
                         config=config_response, 
                         battery=battery_response,
                         location=location_response,
                         device_ip=Config.SMSFORWARDER_IP)

# 短信功能
@app.route('/sms', methods=['GET', 'POST'])
def sms():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'send':
            sim_slot = int(request.form.get('sim_slot', 1))
            phone_numbers = request.form.get('phone_numbers', '').strip()
            msg_content = request.form.get('msg_content', '').strip()
            
            if not phone_numbers or not msg_content:
                flash('手机号码和短信内容不能为空', 'error')
                return redirect(url_for('sms'))
            
            response = sms_forwarder_api.send_sms(sim_slot, phone_numbers, msg_content)
            if response.get('code') == 200:
                flash('短信发送成功', 'success')
            else:
                flash(f'短信发送失败: {response.get("msg", "未知错误")}', 'error')
        
        elif action == 'query':
            sms_type = int(request.form.get('sms_type', 1))
            page_num = int(request.form.get('page_num', 1))
            page_size = int(request.form.get('page_size', 10))
            keyword = request.form.get('keyword', '')
            
            response = sms_forwarder_api.query_sms(sms_type, page_num, page_size, keyword)
            if response.get('code') == 200:
                sms_list = response.get('data', [])
                return render_template('sms.html', 
                                     sms_list=sms_list,
                                     sms_type=sms_type,
                                     page_num=page_num,
                                     page_size=page_size,
                                     keyword=keyword)
            else:
                flash(f'查询短信失败: {response.get("msg", "未知错误")}', 'error')
    
    return render_template('sms.html', sms_list=[])

# 通话功能
@app.route('/calls', methods=['GET', 'POST'])
def calls():
    if request.method == 'POST':
        call_type = int(request.form.get('call_type', 0))
        page_num = int(request.form.get('page_num', 1))
        page_size = int(request.form.get('page_size', 10))
        phone_number = request.form.get('phone_number', '')
        
        response = sms_forwarder_api.query_calls(call_type, page_num, page_size, phone_number)
        if response.get('code') == 200:
            call_list = response.get('data', [])
            return render_template('call.html', 
                                 call_list=call_list,
                                 call_type=call_type,
                                 page_num=page_num,
                                 page_size=page_size,
                                 phone_number=phone_number)
        else:
            flash(f'查询通话记录失败: {response.get("msg", "未知错误")}', 'error')
    
    return render_template('call.html', call_list=[])

# 联系人功能
@app.route('/contacts', methods=['GET', 'POST'])
def contacts():
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'query':
            phone_number = request.form.get('phone_number', '')
            name = request.form.get('name', '')
            
            response = sms_forwarder_api.query_contacts(phone_number, name)
            if response.get('code') == 200:
                contact_list = response.get('data', [])
                return render_template('contact.html', 
                                     contact_list=contact_list,
                                     phone_number=phone_number,
                                     name=name)
            else:
                flash(f'查询联系人失败: {response.get("msg", "未知错误")}', 'error')
        
        elif action == 'add':
            phone_number = request.form.get('phone_number', '').strip()
            name = request.form.get('name', '').strip()
            
            if not phone_number:
                flash('手机号码不能为空', 'error')
                return redirect(url_for('contacts'))
            
            response = sms_forwarder_api.add_contact(phone_number, name)
            if response.get('code') == 200:
                flash('联系人添加成功', 'success')
            else:
                flash(f'添加联系人失败: {response.get("msg", "未知错误")}', 'error')
    
    return render_template('contact.html', contact_list=[])

# 电量功能
@app.route('/battery')
def battery():
    response = sms_forwarder_api.query_battery()
    if response.get('code') == 200:
        battery_data = response.get('data', {})
    else:
        battery_data = {}
        flash(f'查询电量失败: {response.get("msg", "未知错误")}', 'error')
    
    return render_template('battery.html', battery=battery_data)

# 定位功能
@app.route('/location')
def location():
    response = sms_forwarder_api.query_location()
    if response.get('code') == 200:
        location_data = response.get('data', {})
    else:
        location_data = {}
        flash(f'查询定位失败: {response.get("msg", "未知错误")}', 'error')
    
    return render_template('location.html', location=location_data)

# WOL功能
@app.route('/wol', methods=['GET', 'POST'])
def wol():
    if request.method == 'POST':
        mac = request.form.get('mac', '').strip().replace('-', ':')
        ip = request.form.get('ip', '').strip()
        port = int(request.form.get('port', 9))
        
        if not mac or not is_valid_mac(mac):
            flash('MAC地址格式不正确', 'error')
            return redirect(url_for('wol'))
        
        response = sms_forwarder_api.send_wol(mac, ip, port)
        if response.get('code') == 200:
            flash('WOL包发送成功', 'success')
        else:
            flash(f'WOL发送失败: {response.get("msg", "未知错误")}', 'error')
    
    return render_template('wol.html')

# API端点 - 用于AJAX请求
@app.route('/api/config')
def api_config():
    response = sms_forwarder_api.query_config()
    return jsonify(response)

@app.route('/api/battery')
def api_battery():
    response = sms_forwarder_api.query_battery()
    return jsonify(response)

@app.route('/api/location')
def api_location():
    response = sms_forwarder_api.query_location()
    return jsonify(response)

if __name__ == '__main__':
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)